const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { Pool } = require('pg');
const { createProducer, createConsumer } = require('./kafka/kafka');
const { log } = require('./common/logger');
const { inc, render } = require('./common/metrics');

const PORT = process.env.PORT || 4002;
const DATABASE_URL = process.env.DATABASE_URL;

const app = express();
app.use(express.json());

const pool = new Pool({ connectionString: DATABASE_URL });
const producer = createProducer();
const consumer = createConsumer('order-service');

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id UUID PRIMARY KEY,
      items JSONB NOT NULL,
      total NUMERIC NOT NULL,
      status TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

async function publish(topic, payload) {
  await producer.send({
    topic,
    messages: [{ value: JSON.stringify(payload) }]
  });
  inc('kafka_messages_published_total');
}

app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1;');
    res.json({ status: 'ok' });
  } catch (e) {
    res.status(500).json({ status: 'error', error: e.message });
  }
});

app.get('/metrics', (_req, res) => {
  res.type('text/plain').send(render());
});

app.post('/orders', async (req, res) => {
  const { items, total } = req.body || {};
  if (!Array.isArray(items) || typeof total !== 'number') {
    return res.status(400).json({ error: 'Body must include items[] and total:number' });
  }

  const id = uuidv4();
  const status = 'CREATED';

  await pool.query(
    'INSERT INTO orders (id, items, total, status) VALUES ($1, $2, $3, $4)',
    [id, JSON.stringify(items), total, status]
  );

  await publish('order.created', { orderId: id, items, total, status });

  log('info', 'Order created', { orderId: id, status });
  inc('orders_created_total');

  res.status(201).json({ orderId: id, status });
});

app.get('/orders/:id', async (req, res) => {
  const { id } = req.params;
  const r = await pool.query('SELECT * FROM orders WHERE id = $1', [id]);
  if (r.rowCount === 0) return res.status(404).json({ error: 'Not found' });
  res.json(r.rows[0]);
});

async function setStatus(orderId, status) {
  await pool.query('UPDATE orders SET status = $2 WHERE id = $1', [orderId, status]);
  log('info', 'Order status updated', { orderId, status });
  inc('orders_status_updates_total');
}

async function runConsumer() {
  await consumer.connect();
  await consumer.subscribe({ topic: 'inventory.reserved', fromBeginning: true });
  await consumer.subscribe({ topic: 'inventory.failed', fromBeginning: true });
  await consumer.subscribe({ topic: 'payment.completed', fromBeginning: true });
  await consumer.subscribe({ topic: 'payment.failed', fromBeginning: true });
  await consumer.subscribe({ topic: 'shipping.created', fromBeginning: true });
  await consumer.subscribe({ topic: 'shipping.failed', fromBeginning: true });

  await consumer.run({
    eachMessage: async ({ topic, message }) => {
      inc('kafka_messages_consumed_total');
      const payload = JSON.parse(message.value.toString());

      if (topic === 'inventory.reserved') {
        await setStatus(payload.orderId, 'INVENTORY_RESERVED');
      } else if (topic === 'inventory.failed') {
        await setStatus(payload.orderId, 'CANCELLED');
      } else if (topic === 'payment.completed') {
        await setStatus(payload.orderId, 'PAID');
      } else if (topic === 'payment.failed') {
        await setStatus(payload.orderId, 'CANCELLED');
      } else if (topic === 'shipping.created') {
        await setStatus(payload.orderId, 'COMPLETED');
      } else if (topic === 'shipping.failed') {
        await setStatus(payload.orderId, 'CANCELLED');
      }
    }
  });
}

async function main() {
  await initDb();
  await producer.connect();
  runConsumer().catch(e => log('error', 'Order consumer error', { error: e.message }));

  app.listen(PORT, () => log('info', `Order Service running`, { port: PORT }));
}

main().catch(e => {
  log('error', 'Order service failed to start', { error: e.message });
  process.exit(1);
});
