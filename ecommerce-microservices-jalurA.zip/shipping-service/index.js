const express = require('express');
const { Pool } = require('pg');
const { createProducer, createConsumer } = require('./kafka/kafka');
const { log } = require('./common/logger');
const { inc, render } = require('./common/metrics');

const PORT = process.env.PORT || 4004;
const DATABASE_URL = process.env.DATABASE_URL;

const app = express();
app.use(express.json());

const pool = new Pool({ connectionString: DATABASE_URL });
const producer = createProducer();
const consumer = createConsumer('shipping-service');

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS shipments (
      order_id UUID PRIMARY KEY,
      status TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

async function publish(topic, payload) {
  await producer.send({ topic, messages: [{ value: JSON.stringify(payload) }] });
  inc('kafka_messages_published_total');
}

function shouldFailShipping(orderId) {
  let sum = 0;
  for (const ch of orderId) sum += ch.charCodeAt(0);
  return (sum % 20) === 0; // ~5%
}

app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1;');
    res.json({ status: 'ok' });
  } catch (e) {
    res.status(500).json({ status: 'error', error: e.message });
  }
});

app.get('/metrics', (_req, res) => {
  res.type('text/plain').send(render());
});

async function createShipment(orderId) {
  const existing = await pool.query('SELECT status FROM shipments WHERE order_id=$1', [orderId]);
  if (existing.rowCount > 0) return existing.rows[0].status;

  const failed = shouldFailShipping(orderId);
  const status = failed ? 'FAILED' : 'CREATED';

  await pool.query('INSERT INTO shipments (order_id, status) VALUES ($1, $2)', [orderId, status]);

  if (failed) {
    await publish('shipping.failed', { orderId, reason: 'COURIER_UNAVAILABLE' });
    log('warn', 'Shipping failed', { orderId });
    inc('shipments_failed_total');
    return 'FAILED';
  }

  await publish('shipping.created', { orderId, status: 'CREATED' });
  log('info', 'Shipping created', { orderId });
  inc('shipments_created_total');
  return 'CREATED';
}

async function runConsumer() {
  await consumer.connect();
  await consumer.subscribe({ topic: 'payment.completed', fromBeginning: true });

  await consumer.run({
    eachMessage: async ({ message }) => {
      inc('kafka_messages_consumed_total');
      const payload = JSON.parse(message.value.toString());
      await createShipment(payload.orderId);
    }
  });
}

async function main() {
  await initDb();
  await producer.connect();
  runConsumer().catch(e => log('error', 'Shipping consumer error', { error: e.message }));

  app.listen(PORT, () => log('info', 'Shipping Service running', { port: PORT }));
}

main().catch(e => {
  log('error', 'Shipping service failed', { error: e.message });
  process.exit(1);
});
