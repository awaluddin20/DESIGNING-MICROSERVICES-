const express = require('express');
const { Pool } = require('pg');
const { createProducer, createConsumer } = require('./kafka/kafka');
const { log } = require('./common/logger');
const { inc, render } = require('./common/metrics');

const PORT = process.env.PORT || 4005;
const DATABASE_URL = process.env.DATABASE_URL;

const app = express();
app.use(express.json());

const pool = new Pool({ connectionString: DATABASE_URL });
const producer = createProducer();
const consumer = createConsumer('inventory-service');

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      product_id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      stock INT NOT NULL DEFAULT 0
    );
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reservations (
      order_id UUID PRIMARY KEY,
      items JSONB NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);

  // Seed data if empty (demo purpose)
  const c = await pool.query('SELECT COUNT(*)::int AS n FROM products;');
  if (c.rows[0].n === 0) {
    await pool.query(
      `INSERT INTO products (product_id, name, stock) VALUES
       ('P001', 'Product 1', 50),
       ('P002', 'Product 2', 50),
       ('P003', 'Product 3', 50);`
    );
    log('info', 'Seeded inventory products');
  }
}

async function publish(topic, payload) {
  await producer.send({ topic, messages: [{ value: JSON.stringify(payload) }] });
  inc('kafka_messages_published_total');
}

app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1;');
    res.json({ status: 'ok' });
  } catch (e) {
    res.status(500).json({ status: 'error', error: e.message });
  }
});

app.get('/metrics', (_req, res) => {
  res.type('text/plain').send(render());
});

// Read-only inventory endpoints (optional but helpful)
app.get('/products', async (_req, res) => {
  const r = await pool.query('SELECT * FROM products ORDER BY product_id');
  inc('inventory_products_list_total');
  res.json(r.rows);
});

async function reserveStock(orderId, items, total) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const exists = await client.query('SELECT 1 FROM reservations WHERE order_id=$1', [orderId]);
    if (exists.rowCount > 0) {
      await client.query('ROLLBACK');
      return;
    }

    for (const it of items) {
      const { productId, qty } = it;
      const r = await client.query('SELECT stock FROM products WHERE product_id=$1 FOR UPDATE', [productId]);
      if (r.rowCount === 0 || r.rows[0].stock < qty) {
        await client.query('ROLLBACK');
        await publish('inventory.failed', { orderId, reason: 'INSUFFICIENT_STOCK', productId });
        log('warn', 'Inventory reserve failed', { orderId, productId });
        return;
      }
    }

    for (const it of items) {
      await client.query('UPDATE products SET stock = stock - $2 WHERE product_id=$1', [it.productId, it.qty]);
    }

    await client.query('INSERT INTO reservations (order_id, items) VALUES ($1, $2)', [orderId, JSON.stringify(items)]);
    await client.query('COMMIT');

    await publish('inventory.reserved', { orderId, items, total });
    log('info', 'Inventory reserved', { orderId });
    inc('inventory_reserved_total');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

async function releaseStock(orderId) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const r = await client.query('SELECT items FROM reservations WHERE order_id=$1 FOR UPDATE', [orderId]);
    if (r.rowCount === 0) {
      await client.query('ROLLBACK');
      return;
    }

    const items = r.rows[0].items;
    for (const it of items) {
      await client.query('UPDATE products SET stock = stock + $2 WHERE product_id=$1', [it.productId, it.qty]);
    }
    await client.query('DELETE FROM reservations WHERE order_id=$1', [orderId]);
    await client.query('COMMIT');

    await publish('inventory.released', { orderId });
    log('info', 'Inventory released (compensation)', { orderId });
    inc('inventory_released_total');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

async function runConsumer() {
  await consumer.connect();
  await consumer.subscribe({ topic: 'order.created', fromBeginning: true });
  await consumer.subscribe({ topic: 'payment.failed', fromBeginning: true });
  await consumer.subscribe({ topic: 'shipping.failed', fromBeginning: true });

  await consumer.run({
    eachMessage: async ({ topic, message }) => {
      inc('kafka_messages_consumed_total');
      const payload = JSON.parse(message.value.toString());

      if (topic === 'order.created') {
        await reserveStock(payload.orderId, payload.items, payload.total);
      }

      if (topic === 'payment.failed' || topic === 'shipping.failed') {
        await releaseStock(payload.orderId);
      }
    }
  });

  log('info', 'Inventory consumer running');
}

async function main() {
  await initDb();
  await producer.connect();
  runConsumer().catch(e => log('error', 'Inventory consumer error', { error: e.message }));

  app.listen(PORT, () => log('info', 'Inventory Service running', { port: PORT }));
}

main().catch(e => {
  log('error', 'Inventory service failed', { error: e.message });
  process.exit(1);
});
