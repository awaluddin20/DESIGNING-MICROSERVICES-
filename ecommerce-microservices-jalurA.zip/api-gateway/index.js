const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { log } = require('./common/logger');

const app = express();
app.use(express.json());

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

// Orders keeps the same prefix because order-service routes are /orders and /orders/:id
app.use('/orders', createProxyMiddleware({
  target: 'http://order-service:4002',
  changeOrigin: true
}));

function stripPrefix(prefix, target) {
  return createProxyMiddleware({
    target,
    changeOrigin: true,
    pathRewrite: (path) => path.replace(new RegExp(`^/${prefix}`), '') || '/'
  });
}

app.use('/payments', stripPrefix('payments', 'http://payment-service:4003'));
app.use('/shipping', stripPrefix('shipping', 'http://shipping-service:4004'));
app.use('/inventory', stripPrefix('inventory', 'http://inventory-service:4005'));
app.use('/catalog', stripPrefix('catalog', 'http://catalog-service:4006'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => log('info', 'API Gateway running', { port: PORT }));
