# E-commerce Microservices (Gateway + Kafka Saga + Postgres)

## Services
- api-gateway (port 3000)
- order-service (port 4002)
- inventory-service (port 4005)
- payment-service (port 4003)
- shipping-service (port 4004)
- catalog-service (port 4006)

## Kafka Topics (Saga Choreography)
- order.created
- inventory.reserved / inventory.failed / inventory.released (compensation)
- payment.completed / payment.failed / payment.refunded (compensation)
- shipping.created / shipping.failed

## Run
```bash
docker compose up --build
```

## Quick Test
### 1) Lihat produk (Catalog)
```bash
curl http://localhost:3000/catalog/products
```

### 2) Buat order (Order -> Inventory -> Payment -> Shipping)
```bash
curl -X POST http://localhost:3000/orders \
  -H "Content-Type: application/json" \
  -d '{
    "items":[{"productId":"P001","qty":2},{"productId":"P002","qty":1}],
    "total":35
  }'
```

Output contoh:
```json
{"orderId":"...","status":"CREATED"}
```

### 3) Cek status order
```bash
curl http://localhost:3000/orders/<ORDER_ID>
```

Status akan bergerak (event-driven):
- CREATED
- INVENTORY_RESERVED
- PAID
- COMPLETED

Jika gagal (payment/shipping), status jadi **CANCELLED** dan kompensasi jalan (inventory.release + payment.refund).

## Health & Metrics
- /health ada di setiap service
- /metrics (counter sederhana) ada di order/payment/shipping/inventory/catalog
