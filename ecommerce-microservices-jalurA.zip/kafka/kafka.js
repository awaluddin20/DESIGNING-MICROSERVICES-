const { Kafka } = require('kafkajs');

const kafka = new Kafka({
  clientId: 'ecommerce-app',
  brokers: ['kafka:9092']
});

function createProducer() {
  return kafka.producer();
}

function createConsumer(groupId) {
  return kafka.consumer({ groupId });
}

module.exports = { createProducer, createConsumer };
