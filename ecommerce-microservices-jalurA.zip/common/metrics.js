let counters = {};

function inc(name, value = 1) {
  counters[name] = (counters[name] || 0) + value;
}

function render() {
  return Object.entries(counters)
    .map(([k, v]) => `${k} ${v}`)
    .join('\n') + '\n';
}

module.exports = { inc, render };
