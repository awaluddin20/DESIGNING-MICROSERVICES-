const express = require('express');
const { Pool } = require('pg');
const { log } = require('./common/logger');
const { inc, render } = require('./common/metrics');

const PORT = process.env.PORT || 4006;
const DATABASE_URL = process.env.DATABASE_URL;

const app = express();
app.use(express.json());

const pool = new Pool({ connectionString: DATABASE_URL });

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      product_id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      price NUMERIC NOT NULL
    );
  `);

  const c = await pool.query('SELECT COUNT(*)::int AS n FROM products;');
  if (c.rows[0].n === 0) {
    await pool.query(
      `INSERT INTO products (product_id, name, price) VALUES
       ('P001', 'Product 1', 10.0),
       ('P002', 'Product 2', 15.0),
       ('P003', 'Product 3', 7.5);`
    );
    log('info', 'Seeded catalog products');
  }
}

app.get('/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1;');
    res.json({ status: 'ok' });
  } catch (e) {
    res.status(500).json({ status: 'error', error: e.message });
  }
});

app.get('/metrics', (_req, res) => {
  res.type('text/plain').send(render());
});

app.get('/products', async (_req, res) => {
  const r = await pool.query('SELECT * FROM products ORDER BY product_id');
  inc('catalog_products_list_total');
  res.json(r.rows);
});

app.get('/products/:id', async (req, res) => {
  const r = await pool.query('SELECT * FROM products WHERE product_id=$1', [req.params.id]);
  if (r.rowCount === 0) return res.status(404).json({ error: 'Not found' });
  inc('catalog_product_get_total');
  res.json(r.rows[0]);
});

async function main() {
  await initDb();
  app.listen(PORT, () => log('info', 'Catalog Service running', { port: PORT }));
}

main().catch(e => {
  log('error', 'Catalog service failed', { error: e.message });
  process.exit(1);
});
